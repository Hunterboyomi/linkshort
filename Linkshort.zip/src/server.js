const express = require('express');
const bodyParser = require('body-parser');
const connectDB = require('./db');
const cors = require('cors');  // Import the CORS middleware
const urlRoutes = require('./routes/urlRoutes');
// const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

//connect to the database
connectDB();

//middleware
app.use(bodyParser.json());

// CORS configuration (update 'your-frontend-domain' with your actual domain)
app.use(cors({
    origin: 'https://your-frontend-domain.vercel.app',  // Replace with your Vercel frontend domain
    optionsSuccessStatus: 200
}));

//middleware to serv static files
app.use('/', urlRoutes);
app.use(express.static('public'));

app.listen(PORT, () => {
    console.log(`Server is running fine on ${PORT}`);
})