const express = require('express');
const urlController = require('../controllers/urlController');


const router = express.Router();

router.post('/api/shorten', urlController.shortenUrl);
router.get('/location/:shortUrl', urlController.redirectToOriginalUrl);

module.exports = router;