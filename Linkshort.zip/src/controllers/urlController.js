const Url = require('../models/urlModel');
const UrlShortener = require('../utils/urlShortener');

class UrlController {
    static async shortenUrl(req, res) {
        try {
            const { originalUrl } = req.body;
            if (!originalUrl) {
                return res.status(400).json({ message: "URL is required" });
            }

            // Generate a unique short URL
            let shortUrl;
            let urlExists = true;
            while (urlExists) {
                shortUrl = UrlShortener.generateShortUrl();
                urlExists = await Url.findOne({ shortUrl });
            }

            // Save the new URL
            const url = new Url({ originalUrl, shortUrl });
            await url.save();

            // Return the newly created URL object
            res.status(201).json({
                originalUrl: url.originalUrl,
                shortUrl: `/location/${url.shortUrl}`  // Add the location prefix here
            });
        } catch (err) {
            res.status(500).json({ message: 'Server error: ' + err.message });
        }
    }

    static async redirectToOriginalUrl(req, res) {
        try {
            const { shortUrl } = req.params;
            const url = await Url.findOne({ shortUrl });

            if (!url) {
                return res.status(404).send('URL NOT FOUND');
            }

            // Increase the click count
            url.clicks += 1;
            await url.save();

            res.redirect(url.originalUrl);
        } catch (err) {
            console.error(err);
            res.status(500).send('Server Error');
        }
    }
}

module.exports = UrlController;
