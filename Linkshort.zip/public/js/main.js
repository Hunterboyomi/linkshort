document.getElementById('shortenBtn').addEventListener('click', async () => {
    const originalUrl = document.getElementById('originalUrl').value;
    if (!originalUrl || !isValidUrl(originalUrl)) {
        alert('Please enter a valid URL');
        return;
    }
    try {
        const response = await fetch('/api/shorten', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ originalUrl })
        });
        const data = await response.json();
        if (data.shortUrl) {
            document.getElementById('result').textContent = `Shortened URL: ${window.location.origin}${data.shortUrl}`;
        } else {
            document.getElementById('result').textContent = 'Error shortening the URL';
        }
    } catch (err) {
        console.error('Error shortening the URL: ', err);
        alert('Error shortening the URL, PLEASE TRY AGAIN');
    }
});

function isValidUrl(string) {
    try {
        new URL(string);
        return true;
    } catch (_) {
        return false;
    }
}
